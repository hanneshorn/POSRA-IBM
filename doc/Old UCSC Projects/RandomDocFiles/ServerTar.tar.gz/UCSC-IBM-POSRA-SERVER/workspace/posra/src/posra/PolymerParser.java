package posra;

public class PolymerParser {
	public static void pParse(String SMILES){
		String[] polyParts = SMILES.split("Po|Lv|Te");	
	}
}
