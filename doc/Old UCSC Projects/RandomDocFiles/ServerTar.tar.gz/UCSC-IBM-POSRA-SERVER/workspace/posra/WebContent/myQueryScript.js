$(document).ready( function() {
	console.log("document ready");	
});
